
public class Conjugations {

	public String[] subjects = {"Yo", "T�", "El/Ella/Usted", "Nosotros", "Ellos/Ellas/Ustedes"};
	public String[] fConjs = {"�", "�s", "�", "emos", "�n"};
	public String[] futurePerfectConjugations;
}
