
public class ConjugateFuturePerfect {

	private String infinitive = null;
	private String conjugated = null;
	public String[] subjects = {"Yo", "T�", "El/Ella/Usted", "Nosotros", "Ellos/Ellas/Ustedes"};
	public String[] future = {"�", "�s", "�", "emos", "�n"};
	
	public ConjugateFuturePerfect(){
		
	}
	
	
	
	
}
