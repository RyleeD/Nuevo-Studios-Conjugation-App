
public class ConjugateFuture {

	private String infinitive = null; // Holds infinitive form of verb
	private String conjugated = null; // Holds conjugated form of verb
	public String[] subjects = {"Yo", "T�", "El/Ella/Usted", "Nosotros", "Ellos/Ellas/Ustedes"}; // Spanish Subject Pronouns.
	public String[] future = {"�", "�s", "�", "emos", "�n"}; // Future Tense conjugative endings
	public String[][] irregularVerbs = {{"haber", "habr�", "habr�s", "habr�", "habremos", "habr�n"},
										{"decir", "dir�", "dir�s", "dir�","diremos","dir�n"},
										{"hacer", "har�", "har�s", "har�", "haremos","har�n"}};
	
	ConjugateFuture(){
		
	}
	
	ConjugateFuture(String verb){
		
	}
	
	
	
	public void setInfinitive(String verb){ // Allows for the verb to change
		
		infinitive = verb;
	}
	
	public void conjugateVerb(){ // Conjugates the verb
		
		String strippedVerb = null;
		
				strippedVerb = infinitive.substring(0, infinitive.length() - 2);
				for(int i = 0; i < future.length; i++){
			
					conjugated = subjects[i] + " " + strippedVerb + future[i];
					System.out.println(conjugated);
				}
	}
}
